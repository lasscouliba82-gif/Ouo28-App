# Add project specific ProGuard rules here.
-keep class com.ouo28.app.** { *; }
