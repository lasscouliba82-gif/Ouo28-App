# Ouo28 - Application Android

## 📱 Description
Application Android pour accéder directement au groupe Facebook **Ouo28**.
Lien du groupe : https://facebook.com/groups/1271526398070872/

---

## 🚀 Comment compiler l'APK (2 méthodes)

### Méthode 1 : Android Studio (Recommandée - Gratuit)

1. **Télécharger Android Studio** : https://developer.android.com/studio
2. **Ouvrir le projet** :
   - Lancer Android Studio
   - Cliquer "Open" et sélectionner le dossier `Ouo28App`
3. **Compiler l'APK** :
   - Menu : `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - Attendre la compilation (2-5 minutes)
4. **Trouver l'APK** :
   - Cliquer sur "locate" dans la notification en bas
   - Fichier : `app/build/outputs/apk/debug/app-debug.apk`

### Méthode 2 : Ligne de commande

```bash
# Sur Linux/Mac
cd Ouo28App
chmod +x gradlew
./gradlew assembleDebug

# Sur Windows
cd Ouo28App
gradlew.bat assembleDebug
```

L'APK sera dans : `app/build/outputs/apk/debug/app-debug.apk`

---

## 📲 Installer l'APK sur Android

1. Copier l'APK sur votre téléphone
2. Activer **"Sources inconnues"** dans Paramètres → Sécurité
3. Ouvrir l'APK et installer
4. L'app **Ouo28** apparaîtra sur votre écran d'accueil !

---

## ✨ Fonctionnalités
- Accès direct au groupe Facebook Ouo28
- Navigation intégrée (bouton retour)
- Interface plein écran
- Connexion Facebook conservée entre les sessions
- Fonctionne sur Android 5.0+

---

## 📁 Structure du projet
```
Ouo28App/
├── app/
│   ├── src/main/
│   │   ├── java/com/ouo28/app/MainActivity.java
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── values/ (strings, styles, colors)
│   │   │   └── mipmap-*/ (icônes)
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
└── settings.gradle
```
